package de.delautrer.game.ui.elements;

import de.delautrer.engine.graphics.IFont;
import de.delautrer.game.ui.UIMeshBuilder;

public class UILabel extends UIElement {
    private String text;

    public UILabel(float width, float height, String text) {
        super(0, 0, width, height);
        this.text = text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public void render(UIMeshBuilder builder, IFont font, float mouseX, float mouseY) {
        if (!isVisible || font == null || text == null)
            return;

        float textY = y + (height / 2.0f) - 10.0f;
        builder.drawText(text, x, textY, 0.2f, font);
    }
}
