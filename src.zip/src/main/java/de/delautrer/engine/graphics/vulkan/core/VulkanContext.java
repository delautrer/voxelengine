package de.delautrer.engine.graphics.vulkan.core;

import de.delautrer.engine.graphics.*;
import de.delautrer.engine.window.Window;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;
import org.lwjgl.glfw.GLFWVulkan;
import java.nio.LongBuffer;

public class VulkanContext implements IGraphicsContext {

    public static boolean validationEnabled = false;

    private VkInstance instance;
    private long surface;
    private VulkanDeviceManager deviceManager;
    private Window window;

    public VulkanContext(Window window) {
        this.window = window;
        createInstance();
        createSurface();
        deviceManager = new VulkanDeviceManager();
        deviceManager.pickPhysicalDevice(instance, surface);
        deviceManager.createLogicalDevice();
    }

    private void createInstance() {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            VkApplicationInfo appInfo = VkApplicationInfo.calloc(stack);
            appInfo.sType(VK10.VK_STRUCTURE_TYPE_APPLICATION_INFO);
            appInfo.pApplicationName(stack.UTF8("Veinstride"));
            appInfo.applicationVersion(VK10.VK_MAKE_VERSION(1, 0, 0));
            appInfo.pEngineName(stack.UTF8("Veinstride      "));
            appInfo.engineVersion(VK10.VK_MAKE_VERSION(1, 0, 0));
            appInfo.apiVersion(VK10.VK_API_VERSION_1_0);

            VkInstanceCreateInfo createInfo = VkInstanceCreateInfo.calloc(stack);
            createInfo.sType(VK10.VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO);
            createInfo.pApplicationInfo(appInfo);

            PointerBuffer requiredExtensions = GLFWVulkan.glfwGetRequiredInstanceExtensions();
            createInfo.ppEnabledExtensionNames(requiredExtensions);

            PointerBuffer pInstance = stack.mallocPointer(1);
            int err;
            if (de.delautrer.Constants.VULKAN_DEBUG) {
                PointerBuffer validationLayers = stack.pointers(stack.UTF8("VK_LAYER_KHRONOS_validation"));
                createInfo.ppEnabledLayerNames(validationLayers);
                System.out.println("[VulkanContext] Attempting to create instance with VK_LAYER_KHRONOS_validation...");
                err = VK10.vkCreateInstance(createInfo, null, pInstance);
                if (err == VK10.VK_SUCCESS) {
                    validationEnabled = true;
                    System.out.println("[VulkanContext] Vulkan Validation Layers successfully enabled.");
                } else {
                    System.err.println("[VulkanContext] Validation layers not present or failed to load. Error: " + err + ". Retrying without validation layers...");
                    createInfo.ppEnabledLayerNames(null);
                    err = VK10.vkCreateInstance(createInfo, null, pInstance);
                    validationEnabled = false;
                }
            } else {
                createInfo.ppEnabledLayerNames(null);
                err = VK10.vkCreateInstance(createInfo, null, pInstance);
                validationEnabled = false;
            }

            if (err != VK10.VK_SUCCESS) {
                throw new RuntimeException("Vulkan-Instanz konnte nicht erstellt werden: " + err);
            }
            instance = new VkInstance(pInstance.get(0), createInfo);
        }
    }

    private void createSurface() {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            LongBuffer pSurface = stack.mallocLong(1);
            if (GLFWVulkan.glfwCreateWindowSurface(instance, window.getHandle(), null, pSurface) != VK10.VK_SUCCESS) {
                throw new RuntimeException("Window Surface konnte nicht erstellt werden");
            }
            surface = pSurface.get(0);
        }
    }

    public VkInstance getInstance() {
        return instance;
    }

    public long getSurface() {
        return surface;
    }

    public VulkanDeviceManager getDeviceManager() {
        return deviceManager;
    }

    public VkPhysicalDevice getPhysicalDevice() {
        return deviceManager.getPhysicalDevice();
    }

    public VkDevice getDevice() {
        return deviceManager.getDevice();
    }

    public VkQueue getGraphicsQueue() {
        return deviceManager.getGraphicsQueue();
    }

    public VkQueue getPresentQueue() {
        return deviceManager.getPresentQueue();
    }

    public int getGraphicsQueueFamily() {
        return deviceManager.getGraphicsQueueFamily();
    }

    public int getTransferQueueFamily() {
        return deviceManager.getTransferQueueFamily();
    }

    public Window getWindow() {
        return window;
    }

    public int findMemoryType(int typeFilter, int properties) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            VkPhysicalDeviceMemoryProperties memProperties = VkPhysicalDeviceMemoryProperties.calloc(stack);
            VK10.vkGetPhysicalDeviceMemoryProperties(deviceManager.getPhysicalDevice(), memProperties);

            for (int i = 0; i < memProperties.memoryTypeCount(); i++) {
                if ((typeFilter & (1 << i)) != 0
                        && (memProperties.memoryTypes(i).propertyFlags() & properties) == properties) {
                    return i;
                }
            }
        }
        throw new RuntimeException("Passender Speichertyp wurde nicht gefunden");
    }

    @Override
    public void waitIdle() {
        if (deviceManager != null && deviceManager.getDevice() != null) {
            VK10.vkDeviceWaitIdle(deviceManager.getDevice());
        }
    }

    /**
     * The VulkanContext itself doesn't own a factory — the factory requires
     * command buffers and pipeline layouts that are created later by
     * VulkanRenderer.
     * Use Engine.getGraphicsFactory() instead, which returns the MasterRenderer's
     * factory.
     */
    @Override
    public IGraphicsFactory getGraphicsFactory() {
        return null; // See Engine.getGraphicsFactory()
    }

    @Override
    public void cleanup() {
        if (deviceManager != null)
            deviceManager.cleanup();
        KHRSurface.vkDestroySurfaceKHR(instance, surface, null);
        VK10.vkDestroyInstance(instance, null);
    }
}
